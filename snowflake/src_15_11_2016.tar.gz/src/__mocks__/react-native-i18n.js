/**
 * # __mocks__/I18n.js
 *
 * A simple mock for I18n
 *
 */
'use strict'

var I18n = {}
I18n.t = jest.genMockFunction()
module.exports = I18n
