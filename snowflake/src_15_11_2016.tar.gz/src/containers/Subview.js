'use strict'
 
import React, {Component} from 'React'
import {
  StyleSheet,
  View,
  Modal, 
  TouchableHighlight, 
  Picker,
  ScrollView, 
} from 'react-native'

import { ListItem, Container, Content, Spinner, Button, Card, CardItem, Text } from 'native-base'

import NavigationBar from 'react-native-navbar'

import {Actions} from 'react-native-router-flux'

import _ from 'underscore'

import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'

import * as jobsActions from '../reducers/jobs/jobsActions'
import * as globalActions from '../reducers/global/globalActions'


import ErrorAlert from '../components/ErrorAlert'

//import vicTheme from '../../Themes/vic_theme';

var I18n = require('react-native-i18n')
import Translations from '../lib/Translations'
I18n.translations = Translations

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    marginTop: 50
  },
  pickerContainer: {
    padding: 10, 
    flex: 1, 
    borderBottomWidth: 5, 
    color: '#333', 
  },
  title: {
    fontSize: 10,
    marginBottom: 4,
    textAlign: 'left',  
  },
  scrollView: {
    height: 300,
    }, 
  text: {
    padding: 10,
    color: '#333', 
    width: 100

  }
});


function mapStateToProps(state) {
  //console.log('state.jobs: ' + state.jobs)
  return {
    jobs: state.jobs,
    global: {
      currentUser: state.global.currentUser.login_id
    }
  }
  
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
                                  ...globalActions,
                                  ...jobsActions }, dispatch)
  }
}


class Subview extends Component {

  constructor(props) {
    super(props)
    this.state = {
      selectedJob: this.props.jobs.selectedJob,
    }
  }

  componentWillReceiveProps (nextprops) {
    this.setState({
      selectedJob: nextprops.jobs.selectedJob
    })
  }

  componentDidMount(){
    console.log('comopnentDidMount')
    //this.props.actions.getCustomers().done()
    //this.props.actions.getBranch(this.props.global.currentUser.login_id).done()
  }

  componentDidUpdate(){
    //console.log('Selectedjob: ' + this.props.jobs.selectedJob)
    
    if(this.props.jobs.customer === undefined){
      this.props.actions.setCustomer('')
    }
    if(this.props.jobs.branch === undefined){
      this.props.actions.setBranch('')
    }
  }

  jobPressHandler(ordine_id){
    this.props.actions.setSelectedJob(ordine_id)
    this.props.actions.setModalVisible(!this.props.jobs.modalVisible)
    Actions.Job()
    //this.props.actions.getJobsDetail(ordine_id)
    //console.log('selectedJob: ' + this.props.jobs.selectedJob)
  }

  buttonPressHandler (getJobs, setModalVisible, customer, branch, type, modalVisible, currentUser) {
    //console.log(customer)
    //console.log(branch)
    //console.log(type)
    getJobs(customer, branch, type)
    setModalVisible(!modalVisible)
    
  }
  
  renderLoadingView() {
    //console.log('this.props.jobs.loaded: ' + this.props.jobs.loaded)
    return (
      <Container>
        <Content style={{marginTop: 150}}>
          <Spinner color='green' />            
        </Content>
      </Container>
    )
  }
  
  renderJobsView() {
    if (!this.props.jobs.loaded) {
      return this.renderLoadingView();
    }
    var _scrollView: ScrollView;
    
    return(
      <Container >
        <Content>
          <Modal
            animationType={"slide"}
            transparent={false}
            visible={this.props.jobs.modalVisible}
            onRequestClose={() => {this.props.actions.setModalVisible(!this.props.jobs.modalVisible)}} >
        
          <ScrollView
            ref={(scrollView) => { _scrollView = scrollView; }}
            automaticallyAdjustContentInsets={false}
            onScroll={() => {}}
            scrollEventThrottle={200}
            style={styles.scrollView}
             >
            
            <Card>
              <Button block info onPress={() => {
                    this.props.actions.setModalVisible(!this.props.jobs.modalVisible)
                    }}>
                    Close
              </Button>
              {this.props.jobs.jobsList.map((l, i) =>
                  <View key={i}>
                    
                    <CardItem header button onPress={this.jobPressHandler.bind(this, l.ordine_id)}>
                      <Text> {l.fk_cliente.nominativo} </Text>
                    </CardItem> 
                   
                    <CardItem>
                      <Text> {l.vessel} </Text>
                      <Text> JobId: {l.showJobId} </Text>
                      <Text> Port: {l.port} </Text>
                    </CardItem> 

                  </View>
                  )}
                
              <Button block info onPress={() => {
                      this.props.actions.setModalVisible(!this.props.jobs.modalVisible)
                      }}>
                      CloseCLoseCLose
              </Button>               
            </Card>
          </ScrollView>
        </Modal>
      </Content>
    </Container>
    )
  }
    
  render() {
    
    let onButtonPress = this.buttonPressHandler.bind(null,
                        this.props.actions.getJobs,
                        this.props.actions.setModalVisible, 
                        this.props.jobs.customer,
                        this.props.jobs.branch,
                        this.props.jobs.selectedType, 
                        this.props.jobs.modalVisible, 
                        this.props.global.currentUser
                        )

    
   
    var titleConfig = {
      title: I18n.t('Subview.subview')
    }
  
    var leftButtonConfig = {
      title: I18n.t('Subview.back'),
      handler: Actions.pop
    }
    

    if (!this.props.jobs.loaded) {
      return this.renderLoadingView();
    }
    
    if(this.props.jobs.modalVisible){
      return this.renderJobsView(); 
      }

    return (
      <Container>
        <NavigationBar
          title={titleConfig}
          leftButton={leftButtonConfig} />

        <Content style={{marginTop: 53}} >

          <View style={{flexDirection: 'column', borderBottomWidth: 1, borderColor: 'gray'}} >
            <View style={{flexDirection: 'row'}}>
              <Text style={styles.text}> Customer: </Text>
              <Picker
                style={styles.pickerContainer}
                selectedValue={this.props.jobs.customer}
                onValueChange={(val) => this.props.actions.setCustomer(val)} >
                
                {this.props.jobs.customersArray.map((l, i) =>
                 <Picker.Item  value={l.cliente_id} label={l.nominativo} key={i} /> )}
             
              </Picker>
            </View>
          </View>

          <View style={{flexDirection: 'column', borderBottomWidth: 1, borderColor: 'gray'}} >
            <View style={{flexDirection: 'row'}}>
              <Text style={styles.text}> Branch: </Text>
                <Picker
                  style={styles.pickerContainer}
                  selectedValue={this.props.jobs.branch}
                  onValueChange={(val) => this.props.actions.setBranch(val)} >
                  
                  {this.props.jobs.branchList.map((l, i) =>
                    <Picker.Item value={l.sede_id} label={l.nome} key={i} /> )}
                </Picker>
            </View>
          </View>

          <View style={{flexDirection: 'column', borderBottomWidth: 1, borderColor: 'gray'}} >
            <View style={{flexDirection: 'row'}}>
              <Text style={styles.text}> State: </Text>
                <Picker
                    style={styles.pickerContainer}
                    selectedValue={this.props.jobs.selectedType}
                    onValueChange={(val) => this.props.actions.setType(val)} >
                    
                    {this.props.jobs.orderType.map((l, i) =>
                      <Picker.Item value={l} label={l} key={i} /> )}
                </Picker> 
            </View>
          </View>

          <Button block info onPress={onButtonPress} >
            Cerca
          </Button>
          
        </Content>
      </Container>
        
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Subview)
