'use strict'

const {
	GET_CUSTOMERS_REQUEST, 
	GET_CUSTOMERS_SUCCESS, 
	GET_CUSTOMERS_FAILURE, 

	GET_JOBS_REQUEST, 
	GET_JOBS_SUCCESS, 
	GET_JOBS_FAILURE, 

	GET_BRANCH_REQUEST, 
	GET_BRANCH_SUCCESS, 
	GET_BRANCH_FAILURE,

	SET_MODAL, 
	SET_CUSTOMER, 
	SET_BRANCH, 
  SET_TYPE, 
  SET_SELECTED_JOB, 

  GET_JOB_DETAIL_REQUEST, 
  GET_JOB_DETAIL_SUCCESS, 
  GET_JOB_DETAIL_FAILURE
} = require('../../lib/constants').default

const BackendFactory = require('../../lib/BackendFactory').default
import {appAuthToken} from '../../lib/AppAuthToken'

export function getCustomersRequest () {
	console.log('getCustomersRequest')
  return {
    type: GET_CUSTOMERS_REQUEST
  }
}
export function getCustomersSuccess (json) {
	//console.log('getCustomersSuccess')
  return {
    type: GET_CUSTOMERS_SUCCESS,
    payload: json
  }
}
export function getCustomersFailure (json) {
	//console.log('getCustomersFailure')
  return {
    type: GET_CUSTOMERS_FAILURE,
    payload: json
  }
}

export function getCustomers () {
	//console.log('getCustomers')
	return dispatch => {
		dispatch(getCustomersRequest())
		return BackendFactory().getCustomers()
		  .then((customers) => {
		  	dispatch(getCustomersSuccess(customers))
		  })
		  .catch((error) => {
		  	dispatch(getCustomersFailure(error))
		  })
	}
}

export function getBranchRequest () {
  return {
    type: GET_BRANCH_REQUEST
  }
}
export function getBranchSuccess (json) {
  return {
    type: GET_BRANCH_SUCCESS,
    payload: json
  }
}
export function getBranchFailure (json) {
  return {
    type: GET_BRANCH_FAILURE,
    payload: json
  }
}

export function getBranch (userId) {
	return dispatch => {
		dispatch(getBranchRequest())
		return BackendFactory().getBranch(userId)
		  .then((branch) => {
		  	dispatch(getBranchSuccess(branch))
		  })
		  .catch((error) => {
		  	dispatch(getBranchFailure(error))
		  })
	}
}

export function getJobsRequest () {
  return {
    type: GET_JOBS_REQUEST
  }
}
export function getJobsSuccess (json) {
  return {
    type: GET_JOBS_SUCCESS,
    payload: json
  }
}
export function getJobsFailure (json) {
  return {
    type: GET_JOBS_FAILURE,
    payload: json
  }
}

export function getJobs (branch_filter, port_filter, status_filter) {
	return dispatch => {
		dispatch(getJobsRequest())
		return BackendFactory().getJobs(branch_filter, port_filter, status_filter)
		  .then((jobs) => {
		  	dispatch(getJobsSuccess(jobs))
		  })
		  .catch((error) => {
		  	dispatch(getJobsFailure(error))
		  })
	}
}

export function getJobsDetailRequest () {
  return {
    type: GET_JOB_DETAIL_REQUEST
  }
}
export function getJobsDetailSuccess (json) {
  return {
    type: GET_JOB_DETAIL_SUCCESS,
    payload: json
  }
}
export function getJobsDetailFailure (json) {
  return {
    type: GET_JOB_DETAIL_FAILURE,
    payload: json
  }
}

export function getJobDetails (jobId) {
	return dispatch => {
		dispatch(getJobsDetailRequest())
		return BackendFactory().getJobDetails(jobId)
		  .then((jobs) => {
		  	dispatch(getJobsDetailSuccess(jobs))
		  	Actions.Tabbar()
		  })
		  .catch((error) => {
		  	dispatch(getJobsDetailFailure(error))
		  })
	}
}

export function setModalVisible(value) {
	return {
		type: SET_MODAL,
		payload: value
	}
}

export function setCustomer(value) {
	return {
		type: SET_CUSTOMER,
		payload: value
	}
}

export function setBranch(value) {
	console.log('SET_BRANCH')
	return {
		type: SET_BRANCH,
		payload: value
	}
}

export function setType(value) {
  return {
    type: SET_TYPE, 
    payload: value
  }
}

export function setSelectedJob(value) {
	return {
		type: SET_SELECTED_JOB, 
		payload: value
	}
}

















