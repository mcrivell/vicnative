'use strict'

const InitialState = require('./jobsInitialState').default

const {
	GET_CUSTOMERS_REQUEST, 
	GET_CUSTOMERS_SUCCESS, 
	GET_CUSTOMERS_FAILURE, 

	GET_JOBS_REQUEST, 
	GET_JOBS_SUCCESS, 
	GET_JOBS_FAILURE, 

	GET_BRANCH_REQUEST, 
  GET_BRANCH_SUCCESS, 
  GET_BRANCH_FAILURE,

	SET_MODAL, 
	SET_CUSTOMER, 
	SET_BRANCH, 
  SET_TYPE,
  SET_SELECTED_JOB, 

  GET_JOB_DETAIL_REQUEST, 
  GET_JOB_DETAIL_SUCCESS, 
  GET_JOB_DETAIL_FAILURE
} = require('../../lib/constants').default

const initialState = new InitialState()

export default function jobsReducer (state = initialState, action) {
	
	let nextProfileState = null

	if (!(state instanceof InitialState))
	  return initialState.mergeDeep(state)

  switch (action.type) {

  	case GET_CUSTOMERS_REQUEST: 
  	case GET_BRANCH_REQUEST:
    case GET_JOBS_REQUEST:
    case GET_JOB_DETAIL_REQUEST:
  		let nextState = state.setIn(['loaded'], false)
  		return nextState

  	case GET_CUSTOMERS_FAILURE: 
  	case GET_BRANCH_FAILURE: 
    case GET_JOBS_FAILURE:
    case GET_JOB_DETAIL_FAILURE:
  		return state.setIn(['loaded'], true)
  		            .setIn(['error'], action.payload)
  	
  	case GET_CUSTOMERS_SUCCESS: 
      //console.log('STATE: ' + state)
  	  return state.setIn(['loaded'], true)
                  .setIn(['customersArray'], action.payload)

    case GET_BRANCH_SUCCESS: 
  	  return state.setIn(['loaded'], true)
                  .setIn(['branchList'], action.payload)
        
    case GET_JOBS_SUCCESS: 
    //console.log('action.payload: ' + JSON.stringify(action.payload))
      return state.setIn(['loaded'], true)
                  .setIn(['jobsList'], action.payload)

    case GET_JOB_DETAIL_SUCCESS: 
      console.log('action.payload: ' + action.payload)
      return state.setIn(['loaded'], true)
                  .setIn(['jobsDetail'], action.payload)
  	
  	case SET_MODAL: 
  		return state.setIn(['modalVisible'], action.payload)

  	case SET_CUSTOMER: 
  		return state.setIn(['customer'], action.payload)

  	case SET_BRANCH: 
  		return state.setIn(['branch'], action.payload)
      
    case SET_TYPE: 
      return state.setIn(['selectedType'], action.payload)

    case SET_SELECTED_JOB: 
      return state.setIn(['selectedJob'], action.payload)


  }

  return state
}
