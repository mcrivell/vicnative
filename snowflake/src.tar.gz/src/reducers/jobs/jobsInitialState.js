'use strict'

const {Record} = require('immutable')

var InitialState = Record({
	modalVisible: false,
	error: null, 
	customersArray: [],
	customer: '',
	branchList: [], 
	branch: '', 
	loaded: '', 
	orderType: ['All', 
	            'Pending', 
	            'Incoming ETA > 3 gg',
	            'Incoming ETA <= 3gg', 
	            'In progress', 
	            'To be reported', 
	            'Finished', 
	            'canceled', 
	            'frozen'], 
	selectedType: '', 
	jobsList: [],
	jobsDetail: [],
})

export default InitialState
